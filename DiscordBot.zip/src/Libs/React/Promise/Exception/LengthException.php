<?php

namespace JaxkDev\DiscordBot\Libs\React\Promise\Exception;

class LengthException extends \LengthException
{
}
